package com.example.report_producer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportProducerApplication.class, args);
	}

}
